# `remove_last_in_array`

Removes the last element of an `array`.

## Inputs

### `array`
The input array.

## Outputs

### `out_array`
The output array, minus its last element.

### `last`
The element removed from the input `array`.