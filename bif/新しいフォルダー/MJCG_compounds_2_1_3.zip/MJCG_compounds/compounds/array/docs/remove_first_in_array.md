# `remove_first_in_array`

Removes the first element of an `array`.

## Inputs

### `array`
The input array.

## Outputs

### `out_array`
The output array, minus its first element.

### `first`
The element removed from the input `array`.