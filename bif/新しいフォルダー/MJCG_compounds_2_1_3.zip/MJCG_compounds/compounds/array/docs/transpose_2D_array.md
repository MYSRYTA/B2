# `transpose_2D_array`

Transposes the dimensions (rows / collums) of a two-dimensional array.

**The node will display as a yellow error state until you plug a 2D array in the `array` input port.**

## Inputs

### `array`
A two-dimensional array.

## Outputs

### `out_array`
The transposed two-dimensional array.
