# `array_average`

Returns the average value of an array.

## Inputs

### `array`
The input `array`, used to calculate the `average`.

## Outputs

### `average`
The average value calculated from the input `array`.