# `distance_between_vectors`

Returns the distance between two given vectors.

## Inputs

### `first`
The first vector.

### `second`
The second vector.

## Outputs

### `distance`
The distance found between the two vectors.