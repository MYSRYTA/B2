# `angle_between_vectors`

Returns the angle between two given vectors.

## Inputs

### `first`
The first vector.

### `second`
The second vector.

## Outputs

### `radians`
The angle in radians.

### `degrees`
The angle in degrees.