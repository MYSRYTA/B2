# `find_quadratic_roots`

Finds the roots of a quatratic equation.

## Inputs

### `a`
The first coefficient.

### `b`
The second coefficient.

### `c`
The third coefficient.

## Outputs

### `roots`
An array holding the quadratic equation's roots. It can contain between 0 and 2 values depending on the input equation's result.
