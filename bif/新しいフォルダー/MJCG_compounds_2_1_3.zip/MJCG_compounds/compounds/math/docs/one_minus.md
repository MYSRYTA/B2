# `one_minus`

Subtracts a value from one.

## Inputs

### `value`
the input value.

## Outputs

### `output`
The result value subtracted from one.
