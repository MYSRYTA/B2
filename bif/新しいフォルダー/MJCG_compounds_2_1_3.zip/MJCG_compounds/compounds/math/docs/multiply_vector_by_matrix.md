# `multiply_vector_by_matrix`

Multiply a vector by a 4x4 matrix.

## Inputs

### `vector`

The vector to multiply.

### `matrix`

The matrix multiplier.

## Outputs

### `out_vector`

The multiplied vector.