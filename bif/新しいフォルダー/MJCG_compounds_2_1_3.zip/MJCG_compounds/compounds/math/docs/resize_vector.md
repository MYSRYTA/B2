# `resize_vector`

Return a resized vector given a new length.

## Inputs

### `vector`
The input vector. 

### `length`
The new length used to resize the vector. 

## Outputs

### `out_vector`
The resized vector.