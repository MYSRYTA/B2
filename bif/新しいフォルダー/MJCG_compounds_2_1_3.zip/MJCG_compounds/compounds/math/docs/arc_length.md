# `arc_length`

Returns the arc length given a radius and an angle.

## Inputs

### `angle`
The angle in degrees.

### `radius`
The radius of the circle.

## Outputs

### `arc_length`
The length of the arc.