# `hash_string`

Hash a string and return a pseudo unique integer.

## Inputs

### `string`
The string to hash.

## Outputs

### `hash`
A pseudo unique interger value.