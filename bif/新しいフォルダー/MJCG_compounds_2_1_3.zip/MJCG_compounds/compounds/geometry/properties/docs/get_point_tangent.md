# `get_point_tangent`

Returns the array of point tangents for a geometric object with points.

## Input

### `geometry`
Any geometric object with points.

## Output

### `point_tangent`
The array of point tangents.
