# `get_point_scale`

Returns the array of point scales for a geometry object.

## Input

### `geometry`
Any geometric object with points.

## Output

### `point_scale`
The array of point scales.
