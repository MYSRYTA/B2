# `get_point_size`

Returns the array of point sizes for a geometry object.

## Input

### `geometry`
Any geometric object with points.

## Output

### `point_size`
The array of point sizes.
