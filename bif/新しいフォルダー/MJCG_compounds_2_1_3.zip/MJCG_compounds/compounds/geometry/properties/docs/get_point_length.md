# `get_point_length`

Returns the array of point lengths for a geometry object.

## Input

### `geometry`
Any geometric object with points.

## Output

### `point_length`
The array of point lengths.
