# `get_point_ratio`

Returns the array of point ratios for a geometric object with points.

## Input

### `geometry`
Any geometric object with points.

## Output

### `point_ratio`
The array of point ratios.
