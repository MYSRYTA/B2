# `get_strand_length`

Returns the array of strand lengths for a strands object. 

## Input

### `geometry`
A strands object.

## Output

### `strand_length`
The array of strand lengths.
