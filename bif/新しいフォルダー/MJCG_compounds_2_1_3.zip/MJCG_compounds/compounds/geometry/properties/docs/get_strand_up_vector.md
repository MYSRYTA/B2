# `get_strand_up_vector`

Returns the array of strand up_vectors for a strands object. 

## Input

### `geometry`
A strands object.

## Output

### `strand_up_vector`
The array of strand up_vectors.
