# `convert_to_points`

Converts geometies into a points objects, while preserving all point_component properties.

## Inputs

### `geometry`
The input geometry.

## Outputs

### `points`
The output points object.
