# `get_strands_end_points`

Returns strands objects's last points.

## Inputs

### `strands`
The input strands object.

## Outputs

### `positions`
The positions of last points.

### `indices`
The indices of the last points.