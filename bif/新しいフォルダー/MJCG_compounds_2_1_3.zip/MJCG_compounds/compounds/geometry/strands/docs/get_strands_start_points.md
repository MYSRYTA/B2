# `get_strands_start_points`

Returns strands objects's first points.

## Inputs

### `strands`
The input strands object.

## Outputs

### `positions`
The positions of the first points.

### `indices`
The indices of the first points.